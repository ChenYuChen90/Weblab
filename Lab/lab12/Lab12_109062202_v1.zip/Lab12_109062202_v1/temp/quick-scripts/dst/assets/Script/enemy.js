
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/enemy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1c1fPVN7pBQYc0iyx79lLb', 'enemy');
// Script/enemy.ts

Object.defineProperty(exports, "__esModule", { value: true });
var score_1 = require("./score");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var enemy = /** @class */ (function (_super) {
    __extends(enemy, _super);
    function enemy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.score = null;
        _this.anim = null;
        _this.collider = null;
        _this.enemyManager = null;
        _this.enemySpeed = 0;
        return _this;
    }
    enemy.prototype.init = function (node) {
        this.score = cc.find("Canvas/score").getComponent(score_1.default);
        this.anim = this.getComponent(cc.Animation);
        this.collider = this.getComponent(cc.PhysicsBoxCollider);
        this.node.opacity = 255;
        this.setInitPos(node);
        this.anim.play('enemy');
    };
    // this function is called when the enemy manager calls "get" API.
    enemy.prototype.reuse = function (enemyManager) {
        this.enemyManager = enemyManager;
    };
    //this function sets the enemy's initial position when it is reused.
    enemy.prototype.setInitPos = function (node) {
        this.node.parent = node;
        // I use random to decide where the enemy appear after reuse.
        if (Math.random() > 0.5) {
            this.node.position = cc.v2(600, -110);
            this.node.scaleX = 1;
            this.enemySpeed = -200;
            this.collider.enabled = true;
            this.collider.offset = cc.v2(20, 0);
            this.collider.apply();
        }
        else {
            this.node.position = cc.v2(-600, -110);
            this.node.scaleX = -1;
            this.enemySpeed = 200;
            this.collider.enabled = true;
            this.collider.offset = cc.v2(-20, 0);
            this.collider.apply();
        }
    };
    // check if current position is out of view.
    enemy.prototype.boundingDetect = function () {
        if (this.node.x > 650 || this.node.x < -650)
            this.enemyManager.put(this.node);
    };
    //if this is called, the enemy will fade out in 1s and go back to the enemy pool.
    enemy.prototype.deadEffect = function () {
        var _this = this;
        this.enemySpeed = 0;
        this.collider.enabled = false;
        var fade = cc.fadeOut(1);
        var finished = cc.callFunc(function () {
            _this.enemyManager.put(_this.node);
        });
        this.node.runAction(cc.sequence(fade, finished));
    };
    enemy.prototype.update = function (dt) {
        this.node.x += this.enemySpeed * dt;
        this.boundingDetect();
    };
    //check if the collision is valid or not, and call "deadEffect" if the collision is valid.
    enemy.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        if (otherCollider.node.name == "bullet" && !otherCollider.node.getComponent('Bullet').isTriggered) {
            otherCollider.node.getComponent('Bullet').isTriggered = true;
            this.score.addOnePoint();
            this.anim.stop();
            this.deadEffect();
        }
    };
    enemy = __decorate([
        ccclass
    ], enemy);
    return enemy;
}(cc.Component));
exports.default = enemy;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxlbmVteS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaUNBQTRCO0FBRXRCLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQW1DLHlCQUFZO0lBQS9DO1FBQUEscUVBaUhDO1FBL0dXLFdBQUssR0FBVSxJQUFJLENBQUM7UUFFcEIsVUFBSSxHQUFHLElBQUksQ0FBQztRQUVaLGNBQVEsR0FBRyxJQUFJLENBQUM7UUFFaEIsa0JBQVksR0FBRyxJQUFJLENBQUM7UUFFcEIsZ0JBQVUsR0FBRyxDQUFDLENBQUM7O0lBdUczQixDQUFDO0lBckdVLG9CQUFJLEdBQVgsVUFBWSxJQUFhO1FBRXJCLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxZQUFZLENBQUMsZUFBSyxDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU1QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBRXhCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVELGtFQUFrRTtJQUNsRSxxQkFBSyxHQUFMLFVBQU0sWUFBWTtRQUVkLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO0lBQ3JDLENBQUM7SUFFRCxvRUFBb0U7SUFDNUQsMEJBQVUsR0FBbEIsVUFBbUIsSUFBYTtRQUU1QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFFeEIsNkRBQTZEO1FBQzdELElBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsRUFDdEI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRXRDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUVyQixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsR0FBRyxDQUFDO1lBRXZCLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUU3QixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVwQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3pCO2FBRUQ7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFdkMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFFdEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7WUFFdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBRTdCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUN6QjtJQUNMLENBQUM7SUFFRCw0Q0FBNEM7SUFDcEMsOEJBQWMsR0FBdEI7UUFFSSxJQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUc7WUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxpRkFBaUY7SUFDekUsMEJBQVUsR0FBbEI7UUFBQSxpQkFhQztRQVhHLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUU5QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXpCLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDdkIsS0FBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQsc0JBQU0sR0FBTixVQUFPLEVBQUU7UUFFTCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUVwQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELDBGQUEwRjtJQUMxRiw4QkFBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLFlBQVksRUFBRSxhQUFhO1FBRS9DLElBQUcsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUNoRztZQUNJLGFBQWEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFFN0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUV6QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBRWpCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztTQUNyQjtJQUNMLENBQUM7SUFoSGdCLEtBQUs7UUFEekIsT0FBTztPQUNhLEtBQUssQ0FpSHpCO0lBQUQsWUFBQztDQWpIRCxBQWlIQyxDQWpIa0MsRUFBRSxDQUFDLFNBQVMsR0FpSDlDO2tCQWpIb0IsS0FBSyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzY29yZSBmcm9tIFwiLi9zY29yZVwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGVuZW15IGV4dGVuZHMgY2MuQ29tcG9uZW50IFxue1xuICAgIHByaXZhdGUgc2NvcmU6IHNjb3JlID0gbnVsbDtcblxuICAgIHByaXZhdGUgYW5pbSA9IG51bGw7XG5cbiAgICBwcml2YXRlIGNvbGxpZGVyID0gbnVsbDtcblxuICAgIHByaXZhdGUgZW5lbXlNYW5hZ2VyID0gbnVsbDtcblxuICAgIHByaXZhdGUgZW5lbXlTcGVlZCA9IDA7XG5cbiAgICBwdWJsaWMgaW5pdChub2RlOiBjYy5Ob2RlKVxuICAgIHsgICBcbiAgICAgICAgdGhpcy5zY29yZSA9IGNjLmZpbmQoXCJDYW52YXMvc2NvcmVcIikuZ2V0Q29tcG9uZW50KHNjb3JlKTtcblxuICAgICAgICB0aGlzLmFuaW0gPSB0aGlzLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuXG4gICAgICAgIHRoaXMuY29sbGlkZXIgPSB0aGlzLmdldENvbXBvbmVudChjYy5QaHlzaWNzQm94Q29sbGlkZXIpO1xuXG4gICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMjU1O1xuXG4gICAgICAgIHRoaXMuc2V0SW5pdFBvcyhub2RlKTtcblxuICAgICAgICB0aGlzLmFuaW0ucGxheSgnZW5lbXknKTtcbiAgICB9XG5cbiAgICAvLyB0aGlzIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aGVuIHRoZSBlbmVteSBtYW5hZ2VyIGNhbGxzIFwiZ2V0XCIgQVBJLlxuICAgIHJldXNlKGVuZW15TWFuYWdlcilcbiAgICB7XG4gICAgICAgIHRoaXMuZW5lbXlNYW5hZ2VyID0gZW5lbXlNYW5hZ2VyO1xuICAgIH1cblxuICAgIC8vdGhpcyBmdW5jdGlvbiBzZXRzIHRoZSBlbmVteSdzIGluaXRpYWwgcG9zaXRpb24gd2hlbiBpdCBpcyByZXVzZWQuXG4gICAgcHJpdmF0ZSBzZXRJbml0UG9zKG5vZGU6IGNjLk5vZGUpXG4gICAge1xuICAgICAgICB0aGlzLm5vZGUucGFyZW50ID0gbm9kZTtcblxuICAgICAgICAvLyBJIHVzZSByYW5kb20gdG8gZGVjaWRlIHdoZXJlIHRoZSBlbmVteSBhcHBlYXIgYWZ0ZXIgcmV1c2UuXG4gICAgICAgIGlmKE1hdGgucmFuZG9tKCkgPiAwLjUpXG4gICAgICAgIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5wb3NpdGlvbiA9IGNjLnYyKDYwMCwgLTExMCk7XG5cbiAgICAgICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuXG4gICAgICAgICAgICB0aGlzLmVuZW15U3BlZWQgPSAtMjAwO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLm9mZnNldCA9IGNjLnYyKDIwLCAwKTtcblxuICAgICAgICAgICAgdGhpcy5jb2xsaWRlci5hcHBseSgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2VcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnBvc2l0aW9uID0gY2MudjIoLTYwMCwgLTExMCk7XG5cbiAgICAgICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAtMTtcblxuICAgICAgICAgICAgdGhpcy5lbmVteVNwZWVkID0gMjAwO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLm9mZnNldCA9IGNjLnYyKC0yMCwgMCk7XG5cbiAgICAgICAgICAgIHRoaXMuY29sbGlkZXIuYXBwbHkoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIGNoZWNrIGlmIGN1cnJlbnQgcG9zaXRpb24gaXMgb3V0IG9mIHZpZXcuXG4gICAgcHJpdmF0ZSBib3VuZGluZ0RldGVjdCgpXG4gICAge1xuICAgICAgICBpZih0aGlzLm5vZGUueCA+IDY1MCB8fCB0aGlzLm5vZGUueCA8IC02NTApXG4gICAgICAgICAgICB0aGlzLmVuZW15TWFuYWdlci5wdXQodGhpcy5ub2RlKTtcbiAgICB9XG5cbiAgICAvL2lmIHRoaXMgaXMgY2FsbGVkLCB0aGUgZW5lbXkgd2lsbCBmYWRlIG91dCBpbiAxcyBhbmQgZ28gYmFjayB0byB0aGUgZW5lbXkgcG9vbC5cbiAgICBwcml2YXRlIGRlYWRFZmZlY3QoKVxuICAgIHtcbiAgICAgICAgdGhpcy5lbmVteVNwZWVkID0gMDtcblxuICAgICAgICB0aGlzLmNvbGxpZGVyLmVuYWJsZWQgPSBmYWxzZTtcblxuICAgICAgICBsZXQgZmFkZSA9IGNjLmZhZGVPdXQoMSk7XG5cbiAgICAgICAgbGV0IGZpbmlzaGVkID0gY2MuY2FsbEZ1bmMoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5lbmVteU1hbmFnZXIucHV0KHRoaXMubm9kZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoZmFkZSwgZmluaXNoZWQpKTtcbiAgICB9XG5cbiAgICB1cGRhdGUoZHQpXG4gICAge1xuICAgICAgICB0aGlzLm5vZGUueCArPSB0aGlzLmVuZW15U3BlZWQgKiBkdDtcblxuICAgICAgICB0aGlzLmJvdW5kaW5nRGV0ZWN0KCk7XG4gICAgfVxuXG4gICAgLy9jaGVjayBpZiB0aGUgY29sbGlzaW9uIGlzIHZhbGlkIG9yIG5vdCwgYW5kIGNhbGwgXCJkZWFkRWZmZWN0XCIgaWYgdGhlIGNvbGxpc2lvbiBpcyB2YWxpZC5cbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmQ29sbGlkZXIsIG90aGVyQ29sbGlkZXIpXG4gICAge1xuICAgICAgICBpZihvdGhlckNvbGxpZGVyLm5vZGUubmFtZSA9PSBcImJ1bGxldFwiICYmICFvdGhlckNvbGxpZGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdCdWxsZXQnKS5pc1RyaWdnZXJlZClcbiAgICAgICAge1xuICAgICAgICAgICAgb3RoZXJDb2xsaWRlci5ub2RlLmdldENvbXBvbmVudCgnQnVsbGV0JykuaXNUcmlnZ2VyZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLnNjb3JlLmFkZE9uZVBvaW50KCk7XG5cbiAgICAgICAgICAgIHRoaXMuYW5pbS5zdG9wKCk7XG5cbiAgICAgICAgICAgIHRoaXMuZGVhZEVmZmVjdCgpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19