
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a7b801wuUdCc4tfD8dqSgRX', 'Player');
// Script/Player.ts

Object.defineProperty(exports, "__esModule", { value: true });
var score_1 = require("./score");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null; //this will use to get animation component
        _this.animateState = null; //this will use to record animationState
        _this.bulletPrefab = null;
        _this.score = null;
        _this.bulletPool = null; // this is a bullet manager, and it control the bullet resource
        _this.playerSpeed = 0;
        _this.zDown = false; // key for player to go left
        _this.xDown = false; // key for player to go right
        _this.jDown = false; // key for player to shoot
        _this.kDown = false; // key for player to jump
        _this.onGround = false;
        _this.isDead = true;
        return _this;
    }
    Player.prototype.onLoad = function () {
        // ===================== TODO =====================
        // 1. Use "this.anim" to record Animation component
        // ================================================
        this.anim = this.getComponent(cc.Animation);
        cc.director.getCollisionManager().enabled = true;
        cc.director.getPhysicsManager().enabled = true;
        this.bulletPool = new cc.NodePool('Bullet');
        var maxBulletNum = 5;
        for (var i = 0; i < maxBulletNum; i++) {
            var bullet = cc.instantiate(this.bulletPrefab);
            this.bulletPool.put(bullet);
        }
    };
    Player.prototype.start = function () {
        // add key down and key up event
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    };
    Player.prototype.update = function (dt) {
        this.playerMovement(dt);
        this.playerAnimation();
    };
    Player.prototype.onKeyDown = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.z:
                this.zDown = true;
                this.xDown = false;
                break;
            case cc.macro.KEY.x:
                this.xDown = true;
                this.zDown = false;
                break;
            case cc.macro.KEY.j:
                this.jDown = true;
                break;
            case cc.macro.KEY.k:
                this.kDown = true;
                break;
        }
    };
    Player.prototype.onKeyUp = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.z:
                this.zDown = false;
                break;
            case cc.macro.KEY.x:
                this.xDown = false;
                break;
            case cc.macro.KEY.j:
                this.jDown = false;
                break;
            case cc.macro.KEY.k:
                this.kDown = false;
                break;
        }
    };
    Player.prototype.playerMovement = function (dt) {
        if (this.isDead)
            this.playerSpeed = 0;
        else if (this.jDown || this.anim.getAnimationState('shoot').isPlaying)
            this.playerSpeed = 0;
        else if (this.zDown)
            this.playerSpeed = -300;
        else if (this.xDown)
            this.playerSpeed = 300;
        else
            this.playerSpeed = 0;
        this.node.x += this.playerSpeed * dt; //move player
    };
    Player.prototype.finish = function () {
        this.isDead = false;
    };
    Player.prototype.playerAnimation = function () {
        this.node.scaleX = (this.zDown) ? -1 : (this.xDown) ? 1 : this.node.scaleX;
        if (this.isDead) {
            //reset player position and play reborn animation
            if (this.animateState == null || this.animateState.name != 'reborn') {
                this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
                // ===================== TODO =====================
                // 1. reset the player's position to (-192, 255)
                // 2. play reborn animation and use "this.animateState" to record animation state
                // 3. register a callback function when reborn animation finish, and set the value of this.isDead to false in the callback function
                // ================================================
                this.node.setPosition(-192, 255);
                this.animateState = this.anim.play("reborn");
                //reset score value
                this.score.resetScore();
            }
        }
        else if (!this.anim.getAnimationState('shoot').isPlaying && !this.anim.getAnimationState('jump').isPlaying && this.onGround) // move animation can play only when shoot or jump animation finished
         {
            if (this.jDown)
                this.animateState = this.anim.play('shoot');
            else if (this.kDown) {
                this.animateState = this.anim.play('jump');
                this.jump();
            }
            else if (this.zDown || this.xDown) {
                if (this.animateState == null || this.animateState.name != 'move') // when first call or last animation is not move
                    this.animateState = this.anim.play('move');
            }
            else {
                //if no key is pressed and the player is on ground, stop all animations and go back to idle
                if (this.animateState == null || this.animateState.name != 'idle')
                    this.animateState = this.anim.play('idle');
            }
        }
    };
    //give velocity to the player
    Player.prototype.jump = function () {
        this.onGround = false;
        this.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 1500);
        // ===================== TODO =====================
        // 1. set the linearVelocity of RigidBody to (0, 1500)
        // ================================================
    };
    // call this when player shoots the bullet.
    Player.prototype.createBullet = function () {
        var bullet = null;
        if (this.bulletPool.size() > 0)
            bullet = this.bulletPool.get(this.bulletPool);
        if (bullet != null)
            bullet.getComponent('Bullet').init(this.node);
    };
    //check if the collision is valid or not
    Player.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        if (otherCollider.tag == 2 && !this.isDead) //enemy tag
            this.isDead = true;
        // ===================== TODO ===================== 
        // 1. Use otherCollider.tag to check if the player collides with ground or block(the tag of both ground and block are 1), 
        // and do step2 and step3 when the condition is true
        // 2. set the value of this.onGround to true
        // 3. check if jump animation still playing, if yes, stop it and play idle animation 
        // ================================================
        if (otherCollider.tag == 1) {
            this.onGround = true;
            if (this.anim.getAnimationState('player_jump').isPlaying) {
                if (this.animateState == 'jump') {
                    this.animateState = 'idle';
                }
            }
        }
    };
    __decorate([
        property(cc.Prefab)
    ], Player.prototype, "bulletPrefab", void 0);
    __decorate([
        property(score_1.default)
    ], Player.prototype, "score", void 0);
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlDQUE0QjtBQUV0QixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUFvQywwQkFBWTtJQUFoRDtRQUFBLHFFQWlQQztRQTlPVyxVQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsMENBQTBDO1FBRXZELGtCQUFZLEdBQUcsSUFBSSxDQUFDLENBQUMsd0NBQXdDO1FBRzdELGtCQUFZLEdBQWMsSUFBSSxDQUFDO1FBRy9CLFdBQUssR0FBVSxJQUFJLENBQUM7UUFFcEIsZ0JBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQywrREFBK0Q7UUFFbEYsaUJBQVcsR0FBVyxDQUFDLENBQUM7UUFFeEIsV0FBSyxHQUFZLEtBQUssQ0FBQyxDQUFDLDRCQUE0QjtRQUVwRCxXQUFLLEdBQVksS0FBSyxDQUFDLENBQUMsNkJBQTZCO1FBRXJELFdBQUssR0FBWSxLQUFLLENBQUMsQ0FBQywwQkFBMEI7UUFFbEQsV0FBSyxHQUFZLEtBQUssQ0FBQyxDQUFDLHlCQUF5QjtRQUVqRCxjQUFRLEdBQVksS0FBSyxDQUFDO1FBRTFCLFlBQU0sR0FBWSxJQUFJLENBQUM7O0lBc05uQyxDQUFDO0lBcE5HLHVCQUFNLEdBQU47UUFFSSxtREFBbUQ7UUFDbkQsbURBQW1EO1FBQ25ELG1EQUFtRDtRQUNuRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTVDLEVBQUUsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRWpELEVBQUUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRS9DLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTVDLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztRQUVyQixLQUFJLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxFQUFFLENBQUMsRUFBRSxFQUM1QztZQUNJLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVELHNCQUFLLEdBQUw7UUFFSSxnQ0FBZ0M7UUFDaEMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFM0UsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVELHVCQUFNLEdBQU4sVUFBTyxFQUFFO1FBRUwsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUV4QixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELDBCQUFTLEdBQVQsVUFBVSxLQUFLO1FBRVgsUUFBTyxLQUFLLENBQUMsT0FBTyxFQUNwQjtZQUNJLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFZixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFFbEIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBRW5CLE1BQU07WUFFVixLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRWYsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBRWxCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRUQsd0JBQU8sR0FBUCxVQUFRLEtBQUs7UUFFVCxRQUFPLEtBQUssQ0FBQyxPQUFPLEVBQ3BCO1lBQ0ksS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU8sK0JBQWMsR0FBdEIsVUFBdUIsRUFBRTtRQUVyQixJQUFHLElBQUksQ0FBQyxNQUFNO1lBQ1YsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7YUFDcEIsSUFBRyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUztZQUNoRSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQzthQUNwQixJQUFHLElBQUksQ0FBQyxLQUFLO1lBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLEdBQUcsQ0FBQzthQUN2QixJQUFHLElBQUksQ0FBQyxLQUFLO1lBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7O1lBRXZCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDLENBQUUsYUFBYTtJQUN4RCxDQUFDO0lBRUQsdUJBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3hCLENBQUM7SUFDTyxnQ0FBZSxHQUF2QjtRQUVJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFM0UsSUFBRyxJQUFJLENBQUMsTUFBTSxFQUNkO1lBQ0ksaURBQWlEO1lBQ2pELElBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUSxFQUNsRTtnQkFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUVsRSxtREFBbUQ7Z0JBQ25ELGdEQUFnRDtnQkFDaEQsaUZBQWlGO2dCQUNqRixtSUFBbUk7Z0JBQ25JLG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBRTdDLG1CQUFtQjtnQkFDbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUMzQjtTQUNKO2FBQ0ksSUFBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxxRUFBcUU7U0FDak07WUFDSSxJQUFHLElBQUksQ0FBQyxLQUFLO2dCQUNULElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQzNDLElBQUcsSUFBSSxDQUFDLEtBQUssRUFDbEI7Z0JBQ1EsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFM0MsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ25CO2lCQUNJLElBQUcsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxFQUNoQztnQkFDSSxJQUFHLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLE1BQU0sRUFBRSxnREFBZ0Q7b0JBQzlHLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDbEQ7aUJBRUQ7Z0JBQ0ksMkZBQTJGO2dCQUMzRixJQUFHLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLE1BQU07b0JBQzVELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDbEQ7U0FDSjtJQUNMLENBQUM7SUFFRCw2QkFBNkI7SUFDckIscUJBQUksR0FBWjtRQUVJLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUVoRSxtREFBbUQ7UUFDbkQsc0RBQXNEO1FBQ3RELG1EQUFtRDtJQUN2RCxDQUFDO0lBRUQsMkNBQTJDO0lBQ25DLDZCQUFZLEdBQXBCO1FBRUksSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBRWxCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO1lBQzFCLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFbEQsSUFBRyxNQUFNLElBQUksSUFBSTtZQUNiLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsd0NBQXdDO0lBQ3hDLCtCQUFjLEdBQWQsVUFBZSxPQUFPLEVBQUUsWUFBWSxFQUFFLGFBQWE7UUFFL0MsSUFBRyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsV0FBVztZQUNsRCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUV2QixvREFBb0Q7UUFDcEQsMEhBQTBIO1FBQzFILG9EQUFvRDtRQUNwRCw0Q0FBNEM7UUFDNUMscUZBQXFGO1FBQ3JGLG1EQUFtRDtRQUNuRCxJQUFHLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFDO1lBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ3JCLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLEVBQUM7Z0JBQ3BELElBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxNQUFNLEVBQUM7b0JBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBeE9EO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7Z0RBQ21CO0lBR3ZDO1FBREMsUUFBUSxDQUFDLGVBQUssQ0FBQzt5Q0FDWTtJQVhYLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FpUDFCO0lBQUQsYUFBQztDQWpQRCxBQWlQQyxDQWpQbUMsRUFBRSxDQUFDLFNBQVMsR0FpUC9DO2tCQWpQb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzY29yZSBmcm9tIFwiLi9zY29yZVwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFBsYXllciBleHRlbmRzIGNjLkNvbXBvbmVudCBcbntcblxuICAgIHByaXZhdGUgYW5pbSA9IG51bGw7IC8vdGhpcyB3aWxsIHVzZSB0byBnZXQgYW5pbWF0aW9uIGNvbXBvbmVudFxuXG4gICAgcHJpdmF0ZSBhbmltYXRlU3RhdGUgPSBudWxsOyAvL3RoaXMgd2lsbCB1c2UgdG8gcmVjb3JkIGFuaW1hdGlvblN0YXRlXG5cbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxuICAgIHByaXZhdGUgYnVsbGV0UHJlZmFiOiBjYy5QcmVmYWIgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KHNjb3JlKVxuICAgIHByaXZhdGUgc2NvcmU6IHNjb3JlID0gbnVsbDtcblxuICAgIHByaXZhdGUgYnVsbGV0UG9vbCA9IG51bGw7IC8vIHRoaXMgaXMgYSBidWxsZXQgbWFuYWdlciwgYW5kIGl0IGNvbnRyb2wgdGhlIGJ1bGxldCByZXNvdXJjZVxuXG4gICAgcHJpdmF0ZSBwbGF5ZXJTcGVlZDogbnVtYmVyID0gMDtcblxuICAgIHByaXZhdGUgekRvd246IGJvb2xlYW4gPSBmYWxzZTsgLy8ga2V5IGZvciBwbGF5ZXIgdG8gZ28gbGVmdFxuXG4gICAgcHJpdmF0ZSB4RG93bjogYm9vbGVhbiA9IGZhbHNlOyAvLyBrZXkgZm9yIHBsYXllciB0byBnbyByaWdodFxuXG4gICAgcHJpdmF0ZSBqRG93bjogYm9vbGVhbiA9IGZhbHNlOyAvLyBrZXkgZm9yIHBsYXllciB0byBzaG9vdFxuXG4gICAgcHJpdmF0ZSBrRG93bjogYm9vbGVhbiA9IGZhbHNlOyAvLyBrZXkgZm9yIHBsYXllciB0byBqdW1wXG5cbiAgICBwcml2YXRlIG9uR3JvdW5kOiBib29sZWFuID0gZmFsc2U7XG5cbiAgICBwcml2YXRlIGlzRGVhZDogYm9vbGVhbiA9IHRydWU7XG5cbiAgICBvbkxvYWQoKVxuICAgIHtcbiAgICAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IFRPRE8gPT09PT09PT09PT09PT09PT09PT09XG4gICAgICAgIC8vIDEuIFVzZSBcInRoaXMuYW5pbVwiIHRvIHJlY29yZCBBbmltYXRpb24gY29tcG9uZW50XG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICB0aGlzLmFuaW0gPSB0aGlzLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcblxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMuYnVsbGV0UG9vbCA9IG5ldyBjYy5Ob2RlUG9vbCgnQnVsbGV0Jyk7XG5cbiAgICAgICAgbGV0IG1heEJ1bGxldE51bSA9IDU7XG5cbiAgICAgICAgZm9yKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgbWF4QnVsbGV0TnVtOyBpKyspXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxldCBidWxsZXQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJ1bGxldFByZWZhYik7XG5cbiAgICAgICAgICAgIHRoaXMuYnVsbGV0UG9vbC5wdXQoYnVsbGV0KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHN0YXJ0KCkgXG4gICAge1xuICAgICAgICAvLyBhZGQga2V5IGRvd24gYW5kIGtleSB1cCBldmVudFxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vbihjYy5TeXN0ZW1FdmVudC5FdmVudFR5cGUuS0VZX0RPV04sIHRoaXMub25LZXlEb3duLCB0aGlzKTtcblxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vbihjYy5TeXN0ZW1FdmVudC5FdmVudFR5cGUuS0VZX1VQLCB0aGlzLm9uS2V5VXAsIHRoaXMpO1xuICAgIH1cblxuICAgIHVwZGF0ZShkdClcbiAgICB7XG4gICAgICAgIHRoaXMucGxheWVyTW92ZW1lbnQoZHQpO1xuXG4gICAgICAgIHRoaXMucGxheWVyQW5pbWF0aW9uKCk7XG4gICAgfVxuXG4gICAgb25LZXlEb3duKGV2ZW50KSBcbiAgICB7XG4gICAgICAgIHN3aXRjaChldmVudC5rZXlDb2RlKSBcbiAgICAgICAge1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuejpcblxuICAgICAgICAgICAgICAgIHRoaXMuekRvd24gPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgdGhpcy54RG93biA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLng6XG5cbiAgICAgICAgICAgICAgICB0aGlzLnhEb3duID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIHRoaXMuekRvd24gPSBmYWxzZTtcblxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5qOlxuXG4gICAgICAgICAgICAgICAgdGhpcy5qRG93biA9IHRydWU7XG5cbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuazpcblxuICAgICAgICAgICAgICAgIHRoaXMua0Rvd24gPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvbktleVVwKGV2ZW50KVxuICAgIHtcbiAgICAgICAgc3dpdGNoKGV2ZW50LmtleUNvZGUpIFxuICAgICAgICB7XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS56OlxuXG4gICAgICAgICAgICAgICAgdGhpcy56RG93biA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLng6XG5cbiAgICAgICAgICAgICAgICB0aGlzLnhEb3duID0gZmFsc2U7XG5cbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuajpcblxuICAgICAgICAgICAgICAgIHRoaXMuakRvd24gPSBmYWxzZTtcblxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5rOlxuXG4gICAgICAgICAgICAgICAgdGhpcy5rRG93biA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHBsYXllck1vdmVtZW50KGR0KVxuICAgIHtcbiAgICAgICAgaWYodGhpcy5pc0RlYWQpXG4gICAgICAgICAgICB0aGlzLnBsYXllclNwZWVkID0gMDtcbiAgICAgICAgZWxzZSBpZih0aGlzLmpEb3duIHx8IHRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgnc2hvb3QnKS5pc1BsYXlpbmcpXG4gICAgICAgICAgICB0aGlzLnBsYXllclNwZWVkID0gMDtcbiAgICAgICAgZWxzZSBpZih0aGlzLnpEb3duKVxuICAgICAgICAgICAgdGhpcy5wbGF5ZXJTcGVlZCA9IC0zMDA7XG4gICAgICAgIGVsc2UgaWYodGhpcy54RG93bilcbiAgICAgICAgICAgIHRoaXMucGxheWVyU3BlZWQgPSAzMDA7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHRoaXMucGxheWVyU3BlZWQgPSAwO1xuXG4gICAgICAgIHRoaXMubm9kZS54ICs9IHRoaXMucGxheWVyU3BlZWQgKiBkdDsgIC8vbW92ZSBwbGF5ZXJcbiAgICB9XG5cbiAgICBmaW5pc2goKXtcbiAgICAgICAgdGhpcy5pc0RlYWQgPSBmYWxzZTtcbiAgICB9XG4gICAgcHJpdmF0ZSBwbGF5ZXJBbmltYXRpb24oKVxuICAgIHtcbiAgICAgICAgdGhpcy5ub2RlLnNjYWxlWCA9ICh0aGlzLnpEb3duKSA/IC0xIDogKHRoaXMueERvd24pID8gMSA6IHRoaXMubm9kZS5zY2FsZVg7XG5cbiAgICAgICAgaWYodGhpcy5pc0RlYWQpXG4gICAgICAgIHtcbiAgICAgICAgICAgIC8vcmVzZXQgcGxheWVyIHBvc2l0aW9uIGFuZCBwbGF5IHJlYm9ybiBhbmltYXRpb25cbiAgICAgICAgICAgIGlmKHRoaXMuYW5pbWF0ZVN0YXRlID09IG51bGwgfHwgdGhpcy5hbmltYXRlU3RhdGUubmFtZSAhPSAncmVib3JuJylcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52MigwLCAwKTtcblxuICAgICAgICAgICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PSBUT0RPID09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgICAgICAgIC8vIDEuIHJlc2V0IHRoZSBwbGF5ZXIncyBwb3NpdGlvbiB0byAoLTE5MiwgMjU1KVxuICAgICAgICAgICAgICAgIC8vIDIuIHBsYXkgcmVib3JuIGFuaW1hdGlvbiBhbmQgdXNlIFwidGhpcy5hbmltYXRlU3RhdGVcIiB0byByZWNvcmQgYW5pbWF0aW9uIHN0YXRlXG4gICAgICAgICAgICAgICAgLy8gMy4gcmVnaXN0ZXIgYSBjYWxsYmFjayBmdW5jdGlvbiB3aGVuIHJlYm9ybiBhbmltYXRpb24gZmluaXNoLCBhbmQgc2V0IHRoZSB2YWx1ZSBvZiB0aGlzLmlzRGVhZCB0byBmYWxzZSBpbiB0aGUgY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oLTE5MiwgMjU1KTtcbiAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KFwicmVib3JuXCIpO1xuXG4gICAgICAgICAgICAgICAgLy9yZXNldCBzY29yZSB2YWx1ZVxuICAgICAgICAgICAgICAgIHRoaXMuc2NvcmUucmVzZXRTY29yZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYoIXRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgnc2hvb3QnKS5pc1BsYXlpbmcgJiYgIXRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgnanVtcCcpLmlzUGxheWluZyAmJiB0aGlzLm9uR3JvdW5kKSAvLyBtb3ZlIGFuaW1hdGlvbiBjYW4gcGxheSBvbmx5IHdoZW4gc2hvb3Qgb3IganVtcCBhbmltYXRpb24gZmluaXNoZWRcbiAgICAgICAge1xuICAgICAgICAgICAgaWYodGhpcy5qRG93bilcbiAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KCdzaG9vdCcpO1xuICAgICAgICAgICAgZWxzZSBpZih0aGlzLmtEb3duKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KCdqdW1wJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5qdW1wKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmKHRoaXMuekRvd24gfHwgdGhpcy54RG93bilcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpZih0aGlzLmFuaW1hdGVTdGF0ZSA9PSBudWxsIHx8IHRoaXMuYW5pbWF0ZVN0YXRlLm5hbWUgIT0gJ21vdmUnKSAvLyB3aGVuIGZpcnN0IGNhbGwgb3IgbGFzdCBhbmltYXRpb24gaXMgbm90IG1vdmVcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbmltYXRlU3RhdGUgPSB0aGlzLmFuaW0ucGxheSgnbW92ZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vaWYgbm8ga2V5IGlzIHByZXNzZWQgYW5kIHRoZSBwbGF5ZXIgaXMgb24gZ3JvdW5kLCBzdG9wIGFsbCBhbmltYXRpb25zIGFuZCBnbyBiYWNrIHRvIGlkbGVcbiAgICAgICAgICAgICAgICBpZih0aGlzLmFuaW1hdGVTdGF0ZSA9PSBudWxsIHx8IHRoaXMuYW5pbWF0ZVN0YXRlLm5hbWUgIT0gJ2lkbGUnKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KCdpZGxlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvL2dpdmUgdmVsb2NpdHkgdG8gdGhlIHBsYXllclxuICAgIHByaXZhdGUganVtcCgpXG4gICAge1xuICAgICAgICB0aGlzLm9uR3JvdW5kID0gZmFsc2U7XG4gICAgICAgIHRoaXMuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52MigwLCAxNTAwKTtcblxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT0gVE9ETyA9PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgLy8gMS4gc2V0IHRoZSBsaW5lYXJWZWxvY2l0eSBvZiBSaWdpZEJvZHkgdG8gKDAsIDE1MDApXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIH1cblxuICAgIC8vIGNhbGwgdGhpcyB3aGVuIHBsYXllciBzaG9vdHMgdGhlIGJ1bGxldC5cbiAgICBwcml2YXRlIGNyZWF0ZUJ1bGxldCgpXG4gICAge1xuICAgICAgICBsZXQgYnVsbGV0ID0gbnVsbDtcblxuICAgICAgICBpZiAodGhpcy5idWxsZXRQb29sLnNpemUoKSA+IDApIFxuICAgICAgICAgICAgYnVsbGV0ID0gdGhpcy5idWxsZXRQb29sLmdldCh0aGlzLmJ1bGxldFBvb2wpO1xuXG4gICAgICAgIGlmKGJ1bGxldCAhPSBudWxsKVxuICAgICAgICAgICAgYnVsbGV0LmdldENvbXBvbmVudCgnQnVsbGV0JykuaW5pdCh0aGlzLm5vZGUpO1xuICAgIH1cblxuICAgIC8vY2hlY2sgaWYgdGhlIGNvbGxpc2lvbiBpcyB2YWxpZCBvciBub3RcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmQ29sbGlkZXIsIG90aGVyQ29sbGlkZXIpXG4gICAge1xuICAgICAgICBpZihvdGhlckNvbGxpZGVyLnRhZyA9PSAyICYmICF0aGlzLmlzRGVhZCkgLy9lbmVteSB0YWdcbiAgICAgICAgICAgIHRoaXMuaXNEZWFkID0gdHJ1ZTtcblxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT0gVE9ETyA9PT09PT09PT09PT09PT09PT09PT0gXG4gICAgICAgIC8vIDEuIFVzZSBvdGhlckNvbGxpZGVyLnRhZyB0byBjaGVjayBpZiB0aGUgcGxheWVyIGNvbGxpZGVzIHdpdGggZ3JvdW5kIG9yIGJsb2NrKHRoZSB0YWcgb2YgYm90aCBncm91bmQgYW5kIGJsb2NrIGFyZSAxKSwgXG4gICAgICAgIC8vIGFuZCBkbyBzdGVwMiBhbmQgc3RlcDMgd2hlbiB0aGUgY29uZGl0aW9uIGlzIHRydWVcbiAgICAgICAgLy8gMi4gc2V0IHRoZSB2YWx1ZSBvZiB0aGlzLm9uR3JvdW5kIHRvIHRydWVcbiAgICAgICAgLy8gMy4gY2hlY2sgaWYganVtcCBhbmltYXRpb24gc3RpbGwgcGxheWluZywgaWYgeWVzLCBzdG9wIGl0IGFuZCBwbGF5IGlkbGUgYW5pbWF0aW9uIFxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgaWYob3RoZXJDb2xsaWRlci50YWcgPT0gMSl7XG4gICAgICAgICAgICB0aGlzLm9uR3JvdW5kID0gdHJ1ZTtcbiAgICAgICAgICAgIGlmKHRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgncGxheWVyX2p1bXAnKS5pc1BsYXlpbmcpe1xuICAgICAgICAgICAgICAgIGlmKHRoaXMuYW5pbWF0ZVN0YXRlID09ICdqdW1wJyl7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYW5pbWF0ZVN0YXRlID0gJ2lkbGUnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iXX0=