
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Bullet');
require('./assets/Script/Player');
require('./assets/Script/enemy');
require('./assets/Script/enemyManager');
require('./assets/Script/score');
require('./assets/migration/use_reversed_rotateTo');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/enemyManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0b908C7+d1JmJPcFSBmVdWn', 'enemyManager');
// Script/enemyManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var enemyManager = /** @class */ (function (_super) {
    __extends(enemyManager, _super);
    function enemyManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.enemyPrefab = null;
        _this.enemyPool = null;
        return _this;
    }
    enemyManager.prototype.onLoad = function () {
        this.enemyPool = new cc.NodePool('enemy');
        var maxEnemyNum = 3;
        for (var i = 0; i < maxEnemyNum; i++) {
            var enemy = cc.instantiate(this.enemyPrefab);
            this.enemyPool.put(enemy);
        }
        this.schedule(this.createEnemy, 0.5); //set one enemy to the scene every 0.5s .
    };
    //call this function to add new enemy to the scene.
    enemyManager.prototype.createEnemy = function () {
        var enemy = null;
        if (this.enemyPool.size() > 0)
            enemy = this.enemyPool.get(this.enemyPool);
        if (enemy != null)
            enemy.getComponent('enemy').init(this.node);
    };
    __decorate([
        property(cc.Prefab)
    ], enemyManager.prototype, "enemyPrefab", void 0);
    enemyManager = __decorate([
        ccclass
    ], enemyManager);
    return enemyManager;
}(cc.Component));
exports.default = enemyManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxlbmVteU1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQTBDLGdDQUFZO0lBQXREO1FBQUEscUVBbUNDO1FBaENXLGlCQUFXLEdBQWMsSUFBSSxDQUFDO1FBRTlCLGVBQVMsR0FBRyxJQUFJLENBQUM7O0lBOEI3QixDQUFDO0lBNUJHLDZCQUFNLEdBQU47UUFFSSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUxQyxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUM7UUFFcEIsS0FBSSxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsRUFBRSxDQUFDLEVBQUUsRUFDM0M7WUFDSSxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUU3QyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLHlDQUF5QztJQUNuRixDQUFDO0lBRUQsbURBQW1EO0lBQzNDLGtDQUFXLEdBQW5CO1FBRUksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBRWpCLElBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO1lBQ3hCLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFL0MsSUFBRyxLQUFLLElBQUksSUFBSTtZQUNaLEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBOUJEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7cURBQ2tCO0lBSHJCLFlBQVk7UUFEaEMsT0FBTztPQUNhLFlBQVksQ0FtQ2hDO0lBQUQsbUJBQUM7Q0FuQ0QsQUFtQ0MsQ0FuQ3lDLEVBQUUsQ0FBQyxTQUFTLEdBbUNyRDtrQkFuQ29CLFlBQVkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGVuZW15TWFuYWdlciBleHRlbmRzIGNjLkNvbXBvbmVudCBcbntcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxuICAgIHByaXZhdGUgZW5lbXlQcmVmYWI6IGNjLlByZWZhYiA9IG51bGw7XG5cbiAgICBwcml2YXRlIGVuZW15UG9vbCA9IG51bGw7XG5cbiAgICBvbkxvYWQoKVxuICAgIHtcbiAgICAgICAgdGhpcy5lbmVteVBvb2wgPSBuZXcgY2MuTm9kZVBvb2woJ2VuZW15Jyk7XG5cbiAgICAgICAgbGV0IG1heEVuZW15TnVtID0gMztcblxuICAgICAgICBmb3IobGV0IGk6IG51bWJlciA9IDA7IGkgPCBtYXhFbmVteU51bTsgaSsrKVxuICAgICAgICB7XG4gICAgICAgICAgICBsZXQgZW5lbXkgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmVuZW15UHJlZmFiKTtcblxuICAgICAgICAgICAgdGhpcy5lbmVteVBvb2wucHV0KGVuZW15KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2NoZWR1bGUodGhpcy5jcmVhdGVFbmVteSwgMC41KTsgLy9zZXQgb25lIGVuZW15IHRvIHRoZSBzY2VuZSBldmVyeSAwLjVzIC5cbiAgICB9XG5cbiAgICAvL2NhbGwgdGhpcyBmdW5jdGlvbiB0byBhZGQgbmV3IGVuZW15IHRvIHRoZSBzY2VuZS5cbiAgICBwcml2YXRlIGNyZWF0ZUVuZW15KClcbiAgICB7XG4gICAgICAgIGxldCBlbmVteSA9IG51bGw7XG5cbiAgICAgICAgaWYodGhpcy5lbmVteVBvb2wuc2l6ZSgpID4gMClcbiAgICAgICAgICAgIGVuZW15ID0gdGhpcy5lbmVteVBvb2wuZ2V0KHRoaXMuZW5lbXlQb29sKTtcblxuICAgICAgICBpZihlbmVteSAhPSBudWxsKVxuICAgICAgICAgICAgZW5lbXkuZ2V0Q29tcG9uZW50KCdlbmVteScpLmluaXQodGhpcy5ub2RlKTtcbiAgICB9XG4gICAgXG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_reversed_rotateTo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '78d6cG5oG5FeZNWVyqElyEQ', 'use_reversed_rotateTo');
// migration/use_reversed_rotateTo.js

"use strict";

/*
 * This script is automatically generated by Cocos Creator and is only used for projects compatible with v2.1.0/v2.1.1/v2.2.1/v2.2.2 versions.
 * You do not need to manually add this script in any other project.
 * If you don't use cc.Action in your project, you can delete this script directly.
 * If your project is hosted in VCS such as git, submit this script together.
 *
 * 此脚本由 Cocos Creator 自动生成，仅用于兼容 v2.1.0/v2.1.1/v2.2.1/v2.2.2 版本的工程，
 * 你无需在任何其它项目中手动添加此脚本。
 * 如果你的项目中没用到 Action，可直接删除该脚本。
 * 如果你的项目有托管于 git 等版本库，请将此脚本一并上传。
 */
cc.RotateTo._reverse = true;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbWlncmF0aW9uXFx1c2VfcmV2ZXJzZWRfcm90YXRlVG8uanMiXSwibmFtZXMiOlsiY2MiLCJSb3RhdGVUbyIsIl9yZXZlcnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxRQUFILENBQVlDLFFBQVosR0FBdUIsSUFBdkIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBUaGlzIHNjcmlwdCBpcyBhdXRvbWF0aWNhbGx5IGdlbmVyYXRlZCBieSBDb2NvcyBDcmVhdG9yIGFuZCBpcyBvbmx5IHVzZWQgZm9yIHByb2plY3RzIGNvbXBhdGlibGUgd2l0aCB2Mi4xLjAvdjIuMS4xL3YyLjIuMS92Mi4yLjIgdmVyc2lvbnMuXG4gKiBZb3UgZG8gbm90IG5lZWQgdG8gbWFudWFsbHkgYWRkIHRoaXMgc2NyaXB0IGluIGFueSBvdGhlciBwcm9qZWN0LlxuICogSWYgeW91IGRvbid0IHVzZSBjYy5BY3Rpb24gaW4geW91ciBwcm9qZWN0LCB5b3UgY2FuIGRlbGV0ZSB0aGlzIHNjcmlwdCBkaXJlY3RseS5cbiAqIElmIHlvdXIgcHJvamVjdCBpcyBob3N0ZWQgaW4gVkNTIHN1Y2ggYXMgZ2l0LCBzdWJtaXQgdGhpcyBzY3JpcHQgdG9nZXRoZXIuXG4gKlxuICog5q2k6ISa5pys55SxIENvY29zIENyZWF0b3Ig6Ieq5Yqo55Sf5oiQ77yM5LuF55So5LqO5YW85a65IHYyLjEuMC92Mi4xLjEvdjIuMi4xL3YyLjIuMiDniYjmnKznmoTlt6XnqIvvvIxcbiAqIOS9oOaXoOmcgOWcqOS7u+S9leWFtuWug+mhueebruS4reaJi+WKqOa3u+WKoOatpOiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5Lit5rKh55So5YiwIEFjdGlvbu+8jOWPr+ebtOaOpeWIoOmZpOivpeiEmuacrOOAglxuICog5aaC5p6c5L2g55qE6aG555uu5pyJ5omY566h5LqOIGdpdCDnrYnniYjmnKzlupPvvIzor7flsIbmraTohJrmnKzkuIDlubbkuIrkvKDjgIJcbiAqL1xuXG5jYy5Sb3RhdGVUby5fcmV2ZXJzZSA9IHRydWU7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a7b801wuUdCc4tfD8dqSgRX', 'Player');
// Script/Player.ts

Object.defineProperty(exports, "__esModule", { value: true });
var score_1 = require("./score");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null; //this will use to get animation component
        _this.animateState = null; //this will use to record animationState
        _this.bulletPrefab = null;
        _this.score = null;
        _this.bulletPool = null; // this is a bullet manager, and it control the bullet resource
        _this.playerSpeed = 0;
        _this.zDown = false; // key for player to go left
        _this.xDown = false; // key for player to go right
        _this.jDown = false; // key for player to shoot
        _this.kDown = false; // key for player to jump
        _this.onGround = false;
        _this.isDead = true;
        return _this;
    }
    Player.prototype.onLoad = function () {
        // ===================== TODO =====================
        // 1. Use "this.anim" to record Animation component
        // ================================================
        this.anim = this.getComponent(cc.Animation);
        cc.director.getCollisionManager().enabled = true;
        cc.director.getPhysicsManager().enabled = true;
        this.bulletPool = new cc.NodePool('Bullet');
        var maxBulletNum = 5;
        for (var i = 0; i < maxBulletNum; i++) {
            var bullet = cc.instantiate(this.bulletPrefab);
            this.bulletPool.put(bullet);
        }
    };
    Player.prototype.start = function () {
        // add key down and key up event
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    };
    Player.prototype.update = function (dt) {
        this.playerMovement(dt);
        this.playerAnimation();
    };
    Player.prototype.onKeyDown = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.z:
                this.zDown = true;
                this.xDown = false;
                break;
            case cc.macro.KEY.x:
                this.xDown = true;
                this.zDown = false;
                break;
            case cc.macro.KEY.j:
                this.jDown = true;
                break;
            case cc.macro.KEY.k:
                this.kDown = true;
                break;
        }
    };
    Player.prototype.onKeyUp = function (event) {
        switch (event.keyCode) {
            case cc.macro.KEY.z:
                this.zDown = false;
                break;
            case cc.macro.KEY.x:
                this.xDown = false;
                break;
            case cc.macro.KEY.j:
                this.jDown = false;
                break;
            case cc.macro.KEY.k:
                this.kDown = false;
                break;
        }
    };
    Player.prototype.playerMovement = function (dt) {
        if (this.isDead)
            this.playerSpeed = 0;
        else if (this.jDown || this.anim.getAnimationState('shoot').isPlaying)
            this.playerSpeed = 0;
        else if (this.zDown)
            this.playerSpeed = -300;
        else if (this.xDown)
            this.playerSpeed = 300;
        else
            this.playerSpeed = 0;
        this.node.x += this.playerSpeed * dt; //move player
    };
    Player.prototype.finish = function () {
        this.isDead = false;
    };
    Player.prototype.playerAnimation = function () {
        this.node.scaleX = (this.zDown) ? -1 : (this.xDown) ? 1 : this.node.scaleX;
        if (this.isDead) {
            //reset player position and play reborn animation
            if (this.animateState == null || this.animateState.name != 'reborn') {
                this.node.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 0);
                // ===================== TODO =====================
                // 1. reset the player's position to (-192, 255)
                // 2. play reborn animation and use "this.animateState" to record animation state
                // 3. register a callback function when reborn animation finish, and set the value of this.isDead to false in the callback function
                // ================================================
                this.node.setPosition(-192, 255);
                this.animateState = this.anim.play("reborn");
                //reset score value
                this.score.resetScore();
            }
        }
        else if (!this.anim.getAnimationState('shoot').isPlaying && !this.anim.getAnimationState('jump').isPlaying && this.onGround) // move animation can play only when shoot or jump animation finished
         {
            if (this.jDown)
                this.animateState = this.anim.play('shoot');
            else if (this.kDown) {
                this.animateState = this.anim.play('jump');
                this.jump();
            }
            else if (this.zDown || this.xDown) {
                if (this.animateState == null || this.animateState.name != 'move') // when first call or last animation is not move
                    this.animateState = this.anim.play('move');
            }
            else {
                //if no key is pressed and the player is on ground, stop all animations and go back to idle
                if (this.animateState == null || this.animateState.name != 'idle')
                    this.animateState = this.anim.play('idle');
            }
        }
    };
    //give velocity to the player
    Player.prototype.jump = function () {
        this.onGround = false;
        this.getComponent(cc.RigidBody).linearVelocity = cc.v2(0, 1500);
        // ===================== TODO =====================
        // 1. set the linearVelocity of RigidBody to (0, 1500)
        // ================================================
    };
    // call this when player shoots the bullet.
    Player.prototype.createBullet = function () {
        var bullet = null;
        if (this.bulletPool.size() > 0)
            bullet = this.bulletPool.get(this.bulletPool);
        if (bullet != null)
            bullet.getComponent('Bullet').init(this.node);
    };
    //check if the collision is valid or not
    Player.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        if (otherCollider.tag == 2 && !this.isDead) //enemy tag
            this.isDead = true;
        // ===================== TODO ===================== 
        // 1. Use otherCollider.tag to check if the player collides with ground or block(the tag of both ground and block are 1), 
        // and do step2 and step3 when the condition is true
        // 2. set the value of this.onGround to true
        // 3. check if jump animation still playing, if yes, stop it and play idle animation 
        // ================================================
        if (otherCollider.tag == 1) {
            this.onGround = true;
            if (this.anim.getAnimationState('player_jump').isPlaying) {
                if (this.animateState == 'jump') {
                    this.animateState = 'idle';
                }
            }
        }
    };
    __decorate([
        property(cc.Prefab)
    ], Player.prototype, "bulletPrefab", void 0);
    __decorate([
        property(score_1.default)
    ], Player.prototype, "score", void 0);
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlDQUE0QjtBQUV0QixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUFvQywwQkFBWTtJQUFoRDtRQUFBLHFFQWlQQztRQTlPVyxVQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsMENBQTBDO1FBRXZELGtCQUFZLEdBQUcsSUFBSSxDQUFDLENBQUMsd0NBQXdDO1FBRzdELGtCQUFZLEdBQWMsSUFBSSxDQUFDO1FBRy9CLFdBQUssR0FBVSxJQUFJLENBQUM7UUFFcEIsZ0JBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQywrREFBK0Q7UUFFbEYsaUJBQVcsR0FBVyxDQUFDLENBQUM7UUFFeEIsV0FBSyxHQUFZLEtBQUssQ0FBQyxDQUFDLDRCQUE0QjtRQUVwRCxXQUFLLEdBQVksS0FBSyxDQUFDLENBQUMsNkJBQTZCO1FBRXJELFdBQUssR0FBWSxLQUFLLENBQUMsQ0FBQywwQkFBMEI7UUFFbEQsV0FBSyxHQUFZLEtBQUssQ0FBQyxDQUFDLHlCQUF5QjtRQUVqRCxjQUFRLEdBQVksS0FBSyxDQUFDO1FBRTFCLFlBQU0sR0FBWSxJQUFJLENBQUM7O0lBc05uQyxDQUFDO0lBcE5HLHVCQUFNLEdBQU47UUFFSSxtREFBbUQ7UUFDbkQsbURBQW1EO1FBQ25ELG1EQUFtRDtRQUNuRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTVDLEVBQUUsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRWpELEVBQUUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRS9DLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTVDLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztRQUVyQixLQUFJLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxFQUFFLENBQUMsRUFBRSxFQUM1QztZQUNJLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVELHNCQUFLLEdBQUw7UUFFSSxnQ0FBZ0M7UUFDaEMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFM0UsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVELHVCQUFNLEdBQU4sVUFBTyxFQUFFO1FBRUwsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUV4QixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELDBCQUFTLEdBQVQsVUFBVSxLQUFLO1FBRVgsUUFBTyxLQUFLLENBQUMsT0FBTyxFQUNwQjtZQUNJLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFZixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFFbEIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBRW5CLE1BQU07WUFFVixLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRWYsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBRWxCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRUQsd0JBQU8sR0FBUCxVQUFRLEtBQUs7UUFFVCxRQUFPLEtBQUssQ0FBQyxPQUFPLEVBQ3BCO1lBQ0ksS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1lBRVYsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVmLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO2dCQUVuQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU8sK0JBQWMsR0FBdEIsVUFBdUIsRUFBRTtRQUVyQixJQUFHLElBQUksQ0FBQyxNQUFNO1lBQ1YsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7YUFDcEIsSUFBRyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUztZQUNoRSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQzthQUNwQixJQUFHLElBQUksQ0FBQyxLQUFLO1lBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLEdBQUcsQ0FBQzthQUN2QixJQUFHLElBQUksQ0FBQyxLQUFLO1lBQ2QsSUFBSSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7O1lBRXZCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDLENBQUUsYUFBYTtJQUN4RCxDQUFDO0lBRUQsdUJBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3hCLENBQUM7SUFDTyxnQ0FBZSxHQUF2QjtRQUVJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFM0UsSUFBRyxJQUFJLENBQUMsTUFBTSxFQUNkO1lBQ0ksaURBQWlEO1lBQ2pELElBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUSxFQUNsRTtnQkFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUVsRSxtREFBbUQ7Z0JBQ25ELGdEQUFnRDtnQkFDaEQsaUZBQWlGO2dCQUNqRixtSUFBbUk7Z0JBQ25JLG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBRTdDLG1CQUFtQjtnQkFDbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUMzQjtTQUNKO2FBQ0ksSUFBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxxRUFBcUU7U0FDak07WUFDSSxJQUFHLElBQUksQ0FBQyxLQUFLO2dCQUNULElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQzNDLElBQUcsSUFBSSxDQUFDLEtBQUssRUFDbEI7Z0JBQ1EsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFM0MsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ25CO2lCQUNJLElBQUcsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxFQUNoQztnQkFDSSxJQUFHLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLE1BQU0sRUFBRSxnREFBZ0Q7b0JBQzlHLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDbEQ7aUJBRUQ7Z0JBQ0ksMkZBQTJGO2dCQUMzRixJQUFHLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLE1BQU07b0JBQzVELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDbEQ7U0FDSjtJQUNMLENBQUM7SUFFRCw2QkFBNkI7SUFDckIscUJBQUksR0FBWjtRQUVJLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUVoRSxtREFBbUQ7UUFDbkQsc0RBQXNEO1FBQ3RELG1EQUFtRDtJQUN2RCxDQUFDO0lBRUQsMkNBQTJDO0lBQ25DLDZCQUFZLEdBQXBCO1FBRUksSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBRWxCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO1lBQzFCLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFbEQsSUFBRyxNQUFNLElBQUksSUFBSTtZQUNiLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsd0NBQXdDO0lBQ3hDLCtCQUFjLEdBQWQsVUFBZSxPQUFPLEVBQUUsWUFBWSxFQUFFLGFBQWE7UUFFL0MsSUFBRyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsV0FBVztZQUNsRCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUV2QixvREFBb0Q7UUFDcEQsMEhBQTBIO1FBQzFILG9EQUFvRDtRQUNwRCw0Q0FBNEM7UUFDNUMscUZBQXFGO1FBQ3JGLG1EQUFtRDtRQUNuRCxJQUFHLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFDO1lBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ3JCLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLEVBQUM7Z0JBQ3BELElBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxNQUFNLEVBQUM7b0JBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBeE9EO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7Z0RBQ21CO0lBR3ZDO1FBREMsUUFBUSxDQUFDLGVBQUssQ0FBQzt5Q0FDWTtJQVhYLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FpUDFCO0lBQUQsYUFBQztDQWpQRCxBQWlQQyxDQWpQbUMsRUFBRSxDQUFDLFNBQVMsR0FpUC9DO2tCQWpQb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzY29yZSBmcm9tIFwiLi9zY29yZVwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFBsYXllciBleHRlbmRzIGNjLkNvbXBvbmVudCBcbntcblxuICAgIHByaXZhdGUgYW5pbSA9IG51bGw7IC8vdGhpcyB3aWxsIHVzZSB0byBnZXQgYW5pbWF0aW9uIGNvbXBvbmVudFxuXG4gICAgcHJpdmF0ZSBhbmltYXRlU3RhdGUgPSBudWxsOyAvL3RoaXMgd2lsbCB1c2UgdG8gcmVjb3JkIGFuaW1hdGlvblN0YXRlXG5cbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxuICAgIHByaXZhdGUgYnVsbGV0UHJlZmFiOiBjYy5QcmVmYWIgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KHNjb3JlKVxuICAgIHByaXZhdGUgc2NvcmU6IHNjb3JlID0gbnVsbDtcblxuICAgIHByaXZhdGUgYnVsbGV0UG9vbCA9IG51bGw7IC8vIHRoaXMgaXMgYSBidWxsZXQgbWFuYWdlciwgYW5kIGl0IGNvbnRyb2wgdGhlIGJ1bGxldCByZXNvdXJjZVxuXG4gICAgcHJpdmF0ZSBwbGF5ZXJTcGVlZDogbnVtYmVyID0gMDtcblxuICAgIHByaXZhdGUgekRvd246IGJvb2xlYW4gPSBmYWxzZTsgLy8ga2V5IGZvciBwbGF5ZXIgdG8gZ28gbGVmdFxuXG4gICAgcHJpdmF0ZSB4RG93bjogYm9vbGVhbiA9IGZhbHNlOyAvLyBrZXkgZm9yIHBsYXllciB0byBnbyByaWdodFxuXG4gICAgcHJpdmF0ZSBqRG93bjogYm9vbGVhbiA9IGZhbHNlOyAvLyBrZXkgZm9yIHBsYXllciB0byBzaG9vdFxuXG4gICAgcHJpdmF0ZSBrRG93bjogYm9vbGVhbiA9IGZhbHNlOyAvLyBrZXkgZm9yIHBsYXllciB0byBqdW1wXG5cbiAgICBwcml2YXRlIG9uR3JvdW5kOiBib29sZWFuID0gZmFsc2U7XG5cbiAgICBwcml2YXRlIGlzRGVhZDogYm9vbGVhbiA9IHRydWU7XG5cbiAgICBvbkxvYWQoKVxuICAgIHtcbiAgICAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IFRPRE8gPT09PT09PT09PT09PT09PT09PT09XG4gICAgICAgIC8vIDEuIFVzZSBcInRoaXMuYW5pbVwiIHRvIHJlY29yZCBBbmltYXRpb24gY29tcG9uZW50XG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICB0aGlzLmFuaW0gPSB0aGlzLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcblxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMuYnVsbGV0UG9vbCA9IG5ldyBjYy5Ob2RlUG9vbCgnQnVsbGV0Jyk7XG5cbiAgICAgICAgbGV0IG1heEJ1bGxldE51bSA9IDU7XG5cbiAgICAgICAgZm9yKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgbWF4QnVsbGV0TnVtOyBpKyspXG4gICAgICAgIHtcbiAgICAgICAgICAgIGxldCBidWxsZXQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJ1bGxldFByZWZhYik7XG5cbiAgICAgICAgICAgIHRoaXMuYnVsbGV0UG9vbC5wdXQoYnVsbGV0KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHN0YXJ0KCkgXG4gICAge1xuICAgICAgICAvLyBhZGQga2V5IGRvd24gYW5kIGtleSB1cCBldmVudFxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vbihjYy5TeXN0ZW1FdmVudC5FdmVudFR5cGUuS0VZX0RPV04sIHRoaXMub25LZXlEb3duLCB0aGlzKTtcblxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vbihjYy5TeXN0ZW1FdmVudC5FdmVudFR5cGUuS0VZX1VQLCB0aGlzLm9uS2V5VXAsIHRoaXMpO1xuICAgIH1cblxuICAgIHVwZGF0ZShkdClcbiAgICB7XG4gICAgICAgIHRoaXMucGxheWVyTW92ZW1lbnQoZHQpO1xuXG4gICAgICAgIHRoaXMucGxheWVyQW5pbWF0aW9uKCk7XG4gICAgfVxuXG4gICAgb25LZXlEb3duKGV2ZW50KSBcbiAgICB7XG4gICAgICAgIHN3aXRjaChldmVudC5rZXlDb2RlKSBcbiAgICAgICAge1xuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuejpcblxuICAgICAgICAgICAgICAgIHRoaXMuekRvd24gPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgdGhpcy54RG93biA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLng6XG5cbiAgICAgICAgICAgICAgICB0aGlzLnhEb3duID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIHRoaXMuekRvd24gPSBmYWxzZTtcblxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5qOlxuXG4gICAgICAgICAgICAgICAgdGhpcy5qRG93biA9IHRydWU7XG5cbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuazpcblxuICAgICAgICAgICAgICAgIHRoaXMua0Rvd24gPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvbktleVVwKGV2ZW50KVxuICAgIHtcbiAgICAgICAgc3dpdGNoKGV2ZW50LmtleUNvZGUpIFxuICAgICAgICB7XG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS56OlxuXG4gICAgICAgICAgICAgICAgdGhpcy56RG93biA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLng6XG5cbiAgICAgICAgICAgICAgICB0aGlzLnhEb3duID0gZmFsc2U7XG5cbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuajpcblxuICAgICAgICAgICAgICAgIHRoaXMuakRvd24gPSBmYWxzZTtcblxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5rOlxuXG4gICAgICAgICAgICAgICAgdGhpcy5rRG93biA9IGZhbHNlO1xuXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHBsYXllck1vdmVtZW50KGR0KVxuICAgIHtcbiAgICAgICAgaWYodGhpcy5pc0RlYWQpXG4gICAgICAgICAgICB0aGlzLnBsYXllclNwZWVkID0gMDtcbiAgICAgICAgZWxzZSBpZih0aGlzLmpEb3duIHx8IHRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgnc2hvb3QnKS5pc1BsYXlpbmcpXG4gICAgICAgICAgICB0aGlzLnBsYXllclNwZWVkID0gMDtcbiAgICAgICAgZWxzZSBpZih0aGlzLnpEb3duKVxuICAgICAgICAgICAgdGhpcy5wbGF5ZXJTcGVlZCA9IC0zMDA7XG4gICAgICAgIGVsc2UgaWYodGhpcy54RG93bilcbiAgICAgICAgICAgIHRoaXMucGxheWVyU3BlZWQgPSAzMDA7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHRoaXMucGxheWVyU3BlZWQgPSAwO1xuXG4gICAgICAgIHRoaXMubm9kZS54ICs9IHRoaXMucGxheWVyU3BlZWQgKiBkdDsgIC8vbW92ZSBwbGF5ZXJcbiAgICB9XG5cbiAgICBmaW5pc2goKXtcbiAgICAgICAgdGhpcy5pc0RlYWQgPSBmYWxzZTtcbiAgICB9XG4gICAgcHJpdmF0ZSBwbGF5ZXJBbmltYXRpb24oKVxuICAgIHtcbiAgICAgICAgdGhpcy5ub2RlLnNjYWxlWCA9ICh0aGlzLnpEb3duKSA/IC0xIDogKHRoaXMueERvd24pID8gMSA6IHRoaXMubm9kZS5zY2FsZVg7XG5cbiAgICAgICAgaWYodGhpcy5pc0RlYWQpXG4gICAgICAgIHtcbiAgICAgICAgICAgIC8vcmVzZXQgcGxheWVyIHBvc2l0aW9uIGFuZCBwbGF5IHJlYm9ybiBhbmltYXRpb25cbiAgICAgICAgICAgIGlmKHRoaXMuYW5pbWF0ZVN0YXRlID09IG51bGwgfHwgdGhpcy5hbmltYXRlU3RhdGUubmFtZSAhPSAncmVib3JuJylcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52MigwLCAwKTtcblxuICAgICAgICAgICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PSBUT0RPID09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgICAgICAgIC8vIDEuIHJlc2V0IHRoZSBwbGF5ZXIncyBwb3NpdGlvbiB0byAoLTE5MiwgMjU1KVxuICAgICAgICAgICAgICAgIC8vIDIuIHBsYXkgcmVib3JuIGFuaW1hdGlvbiBhbmQgdXNlIFwidGhpcy5hbmltYXRlU3RhdGVcIiB0byByZWNvcmQgYW5pbWF0aW9uIHN0YXRlXG4gICAgICAgICAgICAgICAgLy8gMy4gcmVnaXN0ZXIgYSBjYWxsYmFjayBmdW5jdGlvbiB3aGVuIHJlYm9ybiBhbmltYXRpb24gZmluaXNoLCBhbmQgc2V0IHRoZSB2YWx1ZSBvZiB0aGlzLmlzRGVhZCB0byBmYWxzZSBpbiB0aGUgY2FsbGJhY2sgZnVuY3Rpb25cbiAgICAgICAgICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oLTE5MiwgMjU1KTtcbiAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KFwicmVib3JuXCIpO1xuXG4gICAgICAgICAgICAgICAgLy9yZXNldCBzY29yZSB2YWx1ZVxuICAgICAgICAgICAgICAgIHRoaXMuc2NvcmUucmVzZXRTY29yZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYoIXRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgnc2hvb3QnKS5pc1BsYXlpbmcgJiYgIXRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgnanVtcCcpLmlzUGxheWluZyAmJiB0aGlzLm9uR3JvdW5kKSAvLyBtb3ZlIGFuaW1hdGlvbiBjYW4gcGxheSBvbmx5IHdoZW4gc2hvb3Qgb3IganVtcCBhbmltYXRpb24gZmluaXNoZWRcbiAgICAgICAge1xuICAgICAgICAgICAgaWYodGhpcy5qRG93bilcbiAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KCdzaG9vdCcpO1xuICAgICAgICAgICAgZWxzZSBpZih0aGlzLmtEb3duKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KCdqdW1wJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgdGhpcy5qdW1wKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmKHRoaXMuekRvd24gfHwgdGhpcy54RG93bilcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpZih0aGlzLmFuaW1hdGVTdGF0ZSA9PSBudWxsIHx8IHRoaXMuYW5pbWF0ZVN0YXRlLm5hbWUgIT0gJ21vdmUnKSAvLyB3aGVuIGZpcnN0IGNhbGwgb3IgbGFzdCBhbmltYXRpb24gaXMgbm90IG1vdmVcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbmltYXRlU3RhdGUgPSB0aGlzLmFuaW0ucGxheSgnbW92ZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vaWYgbm8ga2V5IGlzIHByZXNzZWQgYW5kIHRoZSBwbGF5ZXIgaXMgb24gZ3JvdW5kLCBzdG9wIGFsbCBhbmltYXRpb25zIGFuZCBnbyBiYWNrIHRvIGlkbGVcbiAgICAgICAgICAgICAgICBpZih0aGlzLmFuaW1hdGVTdGF0ZSA9PSBudWxsIHx8IHRoaXMuYW5pbWF0ZVN0YXRlLm5hbWUgIT0gJ2lkbGUnKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFuaW1hdGVTdGF0ZSA9IHRoaXMuYW5pbS5wbGF5KCdpZGxlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvL2dpdmUgdmVsb2NpdHkgdG8gdGhlIHBsYXllclxuICAgIHByaXZhdGUganVtcCgpXG4gICAge1xuICAgICAgICB0aGlzLm9uR3JvdW5kID0gZmFsc2U7XG4gICAgICAgIHRoaXMuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52MigwLCAxNTAwKTtcblxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT0gVE9ETyA9PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgLy8gMS4gc2V0IHRoZSBsaW5lYXJWZWxvY2l0eSBvZiBSaWdpZEJvZHkgdG8gKDAsIDE1MDApXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIH1cblxuICAgIC8vIGNhbGwgdGhpcyB3aGVuIHBsYXllciBzaG9vdHMgdGhlIGJ1bGxldC5cbiAgICBwcml2YXRlIGNyZWF0ZUJ1bGxldCgpXG4gICAge1xuICAgICAgICBsZXQgYnVsbGV0ID0gbnVsbDtcblxuICAgICAgICBpZiAodGhpcy5idWxsZXRQb29sLnNpemUoKSA+IDApIFxuICAgICAgICAgICAgYnVsbGV0ID0gdGhpcy5idWxsZXRQb29sLmdldCh0aGlzLmJ1bGxldFBvb2wpO1xuXG4gICAgICAgIGlmKGJ1bGxldCAhPSBudWxsKVxuICAgICAgICAgICAgYnVsbGV0LmdldENvbXBvbmVudCgnQnVsbGV0JykuaW5pdCh0aGlzLm5vZGUpO1xuICAgIH1cblxuICAgIC8vY2hlY2sgaWYgdGhlIGNvbGxpc2lvbiBpcyB2YWxpZCBvciBub3RcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmQ29sbGlkZXIsIG90aGVyQ29sbGlkZXIpXG4gICAge1xuICAgICAgICBpZihvdGhlckNvbGxpZGVyLnRhZyA9PSAyICYmICF0aGlzLmlzRGVhZCkgLy9lbmVteSB0YWdcbiAgICAgICAgICAgIHRoaXMuaXNEZWFkID0gdHJ1ZTtcblxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT0gVE9ETyA9PT09PT09PT09PT09PT09PT09PT0gXG4gICAgICAgIC8vIDEuIFVzZSBvdGhlckNvbGxpZGVyLnRhZyB0byBjaGVjayBpZiB0aGUgcGxheWVyIGNvbGxpZGVzIHdpdGggZ3JvdW5kIG9yIGJsb2NrKHRoZSB0YWcgb2YgYm90aCBncm91bmQgYW5kIGJsb2NrIGFyZSAxKSwgXG4gICAgICAgIC8vIGFuZCBkbyBzdGVwMiBhbmQgc3RlcDMgd2hlbiB0aGUgY29uZGl0aW9uIGlzIHRydWVcbiAgICAgICAgLy8gMi4gc2V0IHRoZSB2YWx1ZSBvZiB0aGlzLm9uR3JvdW5kIHRvIHRydWVcbiAgICAgICAgLy8gMy4gY2hlY2sgaWYganVtcCBhbmltYXRpb24gc3RpbGwgcGxheWluZywgaWYgeWVzLCBzdG9wIGl0IGFuZCBwbGF5IGlkbGUgYW5pbWF0aW9uIFxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgaWYob3RoZXJDb2xsaWRlci50YWcgPT0gMSl7XG4gICAgICAgICAgICB0aGlzLm9uR3JvdW5kID0gdHJ1ZTtcbiAgICAgICAgICAgIGlmKHRoaXMuYW5pbS5nZXRBbmltYXRpb25TdGF0ZSgncGxheWVyX2p1bXAnKS5pc1BsYXlpbmcpe1xuICAgICAgICAgICAgICAgIGlmKHRoaXMuYW5pbWF0ZVN0YXRlID09ICdqdW1wJyl7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYW5pbWF0ZVN0YXRlID0gJ2lkbGUnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/score.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '906760NAB1JXK11rok+U9Ds', 'score');
// Script/score.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var score = /** @class */ (function (_super) {
    __extends(score, _super);
    function score() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.value = 0;
        return _this;
    }
    score.prototype.onLoad = function () {
        this.resetScore();
    };
    score.prototype.resetScore = function () {
        this.value = 0;
        this.node.getComponent(cc.Label).string = "Score: 0";
    };
    score.prototype.addOnePoint = function () {
        this.value++;
        this.node.getComponent(cc.Label).string = "Score: " + this.value.toString();
    };
    score = __decorate([
        ccclass
    ], score);
    return score;
}(cc.Component));
exports.default = score;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxzY29yZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBbUMseUJBQVk7SUFBL0M7UUFBQSxxRUFzQkM7UUFwQlcsV0FBSyxHQUFXLENBQUMsQ0FBQzs7SUFvQjlCLENBQUM7SUFsQkcsc0JBQU0sR0FBTjtRQUVJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRU0sMEJBQVUsR0FBakI7UUFFSSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUVmLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDO0lBQ3pELENBQUM7SUFFTSwyQkFBVyxHQUFsQjtRQUVJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUViLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDaEYsQ0FBQztJQXJCZ0IsS0FBSztRQUR6QixPQUFPO09BQ2EsS0FBSyxDQXNCekI7SUFBRCxZQUFDO0NBdEJELEFBc0JDLENBdEJrQyxFQUFFLENBQUMsU0FBUyxHQXNCOUM7a0JBdEJvQixLQUFLIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBzY29yZSBleHRlbmRzIGNjLkNvbXBvbmVudCBcbntcbiAgICBwcml2YXRlIHZhbHVlOiBudW1iZXIgPSAwO1xuXG4gICAgb25Mb2FkICgpIFxuICAgIHtcbiAgICAgICAgdGhpcy5yZXNldFNjb3JlKCk7XG4gICAgfVxuXG4gICAgcHVibGljIHJlc2V0U2NvcmUoKVxuICAgIHtcbiAgICAgICAgdGhpcy52YWx1ZSA9IDA7XG5cbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gXCJTY29yZTogMFwiO1xuICAgIH1cblxuICAgIHB1YmxpYyBhZGRPbmVQb2ludCgpXG4gICAge1xuICAgICAgICB0aGlzLnZhbHVlKys7XG5cbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gXCJTY29yZTogXCIgKyB0aGlzLnZhbHVlLnRvU3RyaW5nKCk7XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Bullet.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'aeed19u5/dFi79jdO9lf9Vj', 'Bullet');
// Script/Bullet.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Bullet = /** @class */ (function (_super) {
    __extends(Bullet, _super);
    function Bullet() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.anim = null;
        _this.bulletManager = null;
        _this.isTriggered = false; // I add this to make the bullet kill one enemy at a time.
        return _this;
    }
    // when created, the bullet need to be placed at correct position and play animation.
    Bullet.prototype.init = function (node) {
        this.anim = this.getComponent(cc.Animation);
        this.setInitPos(node);
        this.anim.play('bullet');
    };
    // this function is called when the bullet manager calls "get" API.
    Bullet.prototype.reuse = function (bulletManager) {
        this.bulletManager = bulletManager;
        this.isTriggered = false;
    };
    //this function sets the bullet's initial position when it is reused.
    Bullet.prototype.setInitPos = function (node) {
        this.node.parent = node.parent; // don't mount under the player, otherwise it will change direction when player move
        if (node.scaleX > 0) {
            this.node.position = cc.v2(62, 8);
            this.node.scaleX = 1;
        }
        else {
            this.node.position = cc.v2(-62, 8);
            this.node.scaleX = -1;
        }
        this.node.position = this.node.position.addSelf(node.position);
    };
    //make the bullet move from current position
    Bullet.prototype.bulletMove = function () {
        var _this = this;
        var moveDir = null;
        // move bullet to 500 far from current position in 0.8s
        if (this.node.scaleX > 0)
            moveDir = cc.moveBy(0.8, 300, 0);
        else
            moveDir = cc.moveBy(0.8, -300, 0);
        var finished = cc.callFunc(function () {
            _this.bulletManager.put(_this.node);
        });
        // after playing animation, the bullet move 0.8s and destroy itself(put back to the bullet manager)
        this.scheduleOnce(function () {
            _this.node.runAction(cc.sequence(moveDir, finished));
        });
    };
    //detect collision with enemies
    Bullet.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        var _this = this;
        this.node.stopAllActions();
        this.unscheduleAllCallbacks();
        this.scheduleOnce(function () {
            _this.anim.stop();
            _this.bulletManager.put(_this.node);
        }, 0.1); // for better animation effect, I delay 0.1s when bullet hits the enemy
    };
    Bullet = __decorate([
        ccclass
    ], Bullet);
    return Bullet;
}(cc.Component));
exports.default = Bullet;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxCdWxsZXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQW9DLDBCQUFZO0lBQWhEO1FBQUEscUVBbUZDO1FBaEZXLFVBQUksR0FBRyxJQUFJLENBQUM7UUFFWixtQkFBYSxHQUFHLElBQUksQ0FBQztRQUV0QixpQkFBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLDBEQUEwRDs7SUE0RTFGLENBQUM7SUExRUcscUZBQXFGO0lBQzlFLHFCQUFJLEdBQVgsVUFBWSxJQUFhO1FBRXJCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV0QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRUQsbUVBQW1FO0lBQ25FLHNCQUFLLEdBQUwsVUFBTSxhQUFhO1FBRWYsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7UUFFbkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUVELHFFQUFxRTtJQUM3RCwyQkFBVSxHQUFsQixVQUFtQixJQUFhO1FBRTVCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxvRkFBb0Y7UUFFcEgsSUFBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFDbEI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVsQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7U0FDeEI7YUFFRDtZQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFbkMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDekI7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRCw0Q0FBNEM7SUFDcEMsMkJBQVUsR0FBbEI7UUFBQSxpQkFrQkM7UUFoQkcsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRW5CLHVEQUF1RDtRQUN2RCxJQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDbkIsT0FBTyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQzs7WUFFakMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXRDLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDdkIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO1FBRUgsbUdBQW1HO1FBQ25HLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDZCxLQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ3hELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELCtCQUErQjtJQUMvQiwrQkFBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLFlBQVksRUFBRSxhQUFhO1FBQW5ELGlCQVlDO1FBVkcsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUUzQixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUU5QixJQUFJLENBQUMsWUFBWSxDQUFDO1lBRWQsS0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUVqQixLQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsdUVBQXVFO0lBQ3BGLENBQUM7SUFsRmdCLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FtRjFCO0lBQUQsYUFBQztDQW5GRCxBQW1GQyxDQW5GbUMsRUFBRSxDQUFDLFNBQVMsR0FtRi9DO2tCQW5Gb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQnVsbGV0IGV4dGVuZHMgY2MuQ29tcG9uZW50IFxue1xuXG4gICAgcHJpdmF0ZSBhbmltID0gbnVsbDtcblxuICAgIHByaXZhdGUgYnVsbGV0TWFuYWdlciA9IG51bGw7XG5cbiAgICBwdWJsaWMgaXNUcmlnZ2VyZWQgPSBmYWxzZTsgLy8gSSBhZGQgdGhpcyB0byBtYWtlIHRoZSBidWxsZXQga2lsbCBvbmUgZW5lbXkgYXQgYSB0aW1lLlxuXG4gICAgLy8gd2hlbiBjcmVhdGVkLCB0aGUgYnVsbGV0IG5lZWQgdG8gYmUgcGxhY2VkIGF0IGNvcnJlY3QgcG9zaXRpb24gYW5kIHBsYXkgYW5pbWF0aW9uLlxuICAgIHB1YmxpYyBpbml0KG5vZGU6IGNjLk5vZGUpIFxuICAgIHtcbiAgICAgICAgdGhpcy5hbmltID0gdGhpcy5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcblxuICAgICAgICB0aGlzLnNldEluaXRQb3Mobm9kZSk7XG5cbiAgICAgICAgdGhpcy5hbmltLnBsYXkoJ2J1bGxldCcpO1xuICAgIH1cblxuICAgIC8vIHRoaXMgZnVuY3Rpb24gaXMgY2FsbGVkIHdoZW4gdGhlIGJ1bGxldCBtYW5hZ2VyIGNhbGxzIFwiZ2V0XCIgQVBJLlxuICAgIHJldXNlKGJ1bGxldE1hbmFnZXIpXG4gICAge1xuICAgICAgICB0aGlzLmJ1bGxldE1hbmFnZXIgPSBidWxsZXRNYW5hZ2VyO1xuXG4gICAgICAgIHRoaXMuaXNUcmlnZ2VyZWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvL3RoaXMgZnVuY3Rpb24gc2V0cyB0aGUgYnVsbGV0J3MgaW5pdGlhbCBwb3NpdGlvbiB3aGVuIGl0IGlzIHJldXNlZC5cbiAgICBwcml2YXRlIHNldEluaXRQb3Mobm9kZTogY2MuTm9kZSlcbiAgICB7XG4gICAgICAgIHRoaXMubm9kZS5wYXJlbnQgPSBub2RlLnBhcmVudDsgLy8gZG9uJ3QgbW91bnQgdW5kZXIgdGhlIHBsYXllciwgb3RoZXJ3aXNlIGl0IHdpbGwgY2hhbmdlIGRpcmVjdGlvbiB3aGVuIHBsYXllciBtb3ZlXG5cbiAgICAgICAgaWYobm9kZS5zY2FsZVggPiAwKVxuICAgICAgICB7XG4gICAgICAgICAgICB0aGlzLm5vZGUucG9zaXRpb24gPSBjYy52Mig2MiwgOCk7XG5cbiAgICAgICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuICAgICAgICB9XG4gICAgICAgIGVsc2VcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnBvc2l0aW9uID0gY2MudjIoLTYyLCA4KTtcblxuICAgICAgICAgICAgdGhpcy5ub2RlLnNjYWxlWCA9IC0xO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5ub2RlLnBvc2l0aW9uID0gdGhpcy5ub2RlLnBvc2l0aW9uLmFkZFNlbGYobm9kZS5wb3NpdGlvbik7XG4gICAgfVxuXG4gICAgLy9tYWtlIHRoZSBidWxsZXQgbW92ZSBmcm9tIGN1cnJlbnQgcG9zaXRpb25cbiAgICBwcml2YXRlIGJ1bGxldE1vdmUoKVxuICAgIHtcbiAgICAgICAgbGV0IG1vdmVEaXIgPSBudWxsO1xuXG4gICAgICAgIC8vIG1vdmUgYnVsbGV0IHRvIDUwMCBmYXIgZnJvbSBjdXJyZW50IHBvc2l0aW9uIGluIDAuOHNcbiAgICAgICAgaWYodGhpcy5ub2RlLnNjYWxlWCA+IDApXG4gICAgICAgICAgICBtb3ZlRGlyID0gY2MubW92ZUJ5KDAuOCwgMzAwLCAwKTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgbW92ZURpciA9IGNjLm1vdmVCeSgwLjgsIC0zMDAsIDApO1xuXG4gICAgICAgIGxldCBmaW5pc2hlZCA9IGNjLmNhbGxGdW5jKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYnVsbGV0TWFuYWdlci5wdXQodGhpcy5ub2RlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gYWZ0ZXIgcGxheWluZyBhbmltYXRpb24sIHRoZSBidWxsZXQgbW92ZSAwLjhzIGFuZCBkZXN0cm95IGl0c2VsZihwdXQgYmFjayB0byB0aGUgYnVsbGV0IG1hbmFnZXIpXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UobW92ZURpciwgZmluaXNoZWQpKTtcbiAgICAgICAgfSk7IFxuICAgIH1cbiAgICBcbiAgICAvL2RldGVjdCBjb2xsaXNpb24gd2l0aCBlbmVtaWVzXG4gICAgb25CZWdpbkNvbnRhY3QoY29udGFjdCwgc2VsZkNvbGxpZGVyLCBvdGhlckNvbGxpZGVyKVxuICAgIHtcbiAgICAgICAgdGhpcy5ub2RlLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgIFxuICAgICAgICB0aGlzLnVuc2NoZWR1bGVBbGxDYWxsYmFja3MoKTtcblxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSgoKSA9PiB7XG5cbiAgICAgICAgICAgIHRoaXMuYW5pbS5zdG9wKCk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHRoaXMuYnVsbGV0TWFuYWdlci5wdXQodGhpcy5ub2RlKTtcbiAgICAgICAgfSwgMC4xKTsgLy8gZm9yIGJldHRlciBhbmltYXRpb24gZWZmZWN0LCBJIGRlbGF5IDAuMXMgd2hlbiBidWxsZXQgaGl0cyB0aGUgZW5lbXlcbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/enemy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1c1fPVN7pBQYc0iyx79lLb', 'enemy');
// Script/enemy.ts

Object.defineProperty(exports, "__esModule", { value: true });
var score_1 = require("./score");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var enemy = /** @class */ (function (_super) {
    __extends(enemy, _super);
    function enemy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.score = null;
        _this.anim = null;
        _this.collider = null;
        _this.enemyManager = null;
        _this.enemySpeed = 0;
        return _this;
    }
    enemy.prototype.init = function (node) {
        this.score = cc.find("Canvas/score").getComponent(score_1.default);
        this.anim = this.getComponent(cc.Animation);
        this.collider = this.getComponent(cc.PhysicsBoxCollider);
        this.node.opacity = 255;
        this.setInitPos(node);
        this.anim.play('enemy');
    };
    // this function is called when the enemy manager calls "get" API.
    enemy.prototype.reuse = function (enemyManager) {
        this.enemyManager = enemyManager;
    };
    //this function sets the enemy's initial position when it is reused.
    enemy.prototype.setInitPos = function (node) {
        this.node.parent = node;
        // I use random to decide where the enemy appear after reuse.
        if (Math.random() > 0.5) {
            this.node.position = cc.v2(600, -110);
            this.node.scaleX = 1;
            this.enemySpeed = -200;
            this.collider.enabled = true;
            this.collider.offset = cc.v2(20, 0);
            this.collider.apply();
        }
        else {
            this.node.position = cc.v2(-600, -110);
            this.node.scaleX = -1;
            this.enemySpeed = 200;
            this.collider.enabled = true;
            this.collider.offset = cc.v2(-20, 0);
            this.collider.apply();
        }
    };
    // check if current position is out of view.
    enemy.prototype.boundingDetect = function () {
        if (this.node.x > 650 || this.node.x < -650)
            this.enemyManager.put(this.node);
    };
    //if this is called, the enemy will fade out in 1s and go back to the enemy pool.
    enemy.prototype.deadEffect = function () {
        var _this = this;
        this.enemySpeed = 0;
        this.collider.enabled = false;
        var fade = cc.fadeOut(1);
        var finished = cc.callFunc(function () {
            _this.enemyManager.put(_this.node);
        });
        this.node.runAction(cc.sequence(fade, finished));
    };
    enemy.prototype.update = function (dt) {
        this.node.x += this.enemySpeed * dt;
        this.boundingDetect();
    };
    //check if the collision is valid or not, and call "deadEffect" if the collision is valid.
    enemy.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        if (otherCollider.node.name == "bullet" && !otherCollider.node.getComponent('Bullet').isTriggered) {
            otherCollider.node.getComponent('Bullet').isTriggered = true;
            this.score.addOnePoint();
            this.anim.stop();
            this.deadEffect();
        }
    };
    enemy = __decorate([
        ccclass
    ], enemy);
    return enemy;
}(cc.Component));
exports.default = enemy;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxlbmVteS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaUNBQTRCO0FBRXRCLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQW1DLHlCQUFZO0lBQS9DO1FBQUEscUVBaUhDO1FBL0dXLFdBQUssR0FBVSxJQUFJLENBQUM7UUFFcEIsVUFBSSxHQUFHLElBQUksQ0FBQztRQUVaLGNBQVEsR0FBRyxJQUFJLENBQUM7UUFFaEIsa0JBQVksR0FBRyxJQUFJLENBQUM7UUFFcEIsZ0JBQVUsR0FBRyxDQUFDLENBQUM7O0lBdUczQixDQUFDO0lBckdVLG9CQUFJLEdBQVgsVUFBWSxJQUFhO1FBRXJCLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxZQUFZLENBQUMsZUFBSyxDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU1QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBRXhCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVELGtFQUFrRTtJQUNsRSxxQkFBSyxHQUFMLFVBQU0sWUFBWTtRQUVkLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO0lBQ3JDLENBQUM7SUFFRCxvRUFBb0U7SUFDNUQsMEJBQVUsR0FBbEIsVUFBbUIsSUFBYTtRQUU1QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFFeEIsNkRBQTZEO1FBQzdELElBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsRUFDdEI7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRXRDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUVyQixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsR0FBRyxDQUFDO1lBRXZCLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUU3QixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVwQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3pCO2FBRUQ7WUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFdkMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFFdEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7WUFFdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBRTdCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUN6QjtJQUNMLENBQUM7SUFFRCw0Q0FBNEM7SUFDcEMsOEJBQWMsR0FBdEI7UUFFSSxJQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUc7WUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxpRkFBaUY7SUFDekUsMEJBQVUsR0FBbEI7UUFBQSxpQkFhQztRQVhHLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUU5QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXpCLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDdkIsS0FBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQsc0JBQU0sR0FBTixVQUFPLEVBQUU7UUFFTCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUVwQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELDBGQUEwRjtJQUMxRiw4QkFBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLFlBQVksRUFBRSxhQUFhO1FBRS9DLElBQUcsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksUUFBUSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUNoRztZQUNJLGFBQWEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFFN0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUV6QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBRWpCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztTQUNyQjtJQUNMLENBQUM7SUFoSGdCLEtBQUs7UUFEekIsT0FBTztPQUNhLEtBQUssQ0FpSHpCO0lBQUQsWUFBQztDQWpIRCxBQWlIQyxDQWpIa0MsRUFBRSxDQUFDLFNBQVMsR0FpSDlDO2tCQWpIb0IsS0FBSyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzY29yZSBmcm9tIFwiLi9zY29yZVwiO1xuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGVuZW15IGV4dGVuZHMgY2MuQ29tcG9uZW50IFxue1xuICAgIHByaXZhdGUgc2NvcmU6IHNjb3JlID0gbnVsbDtcblxuICAgIHByaXZhdGUgYW5pbSA9IG51bGw7XG5cbiAgICBwcml2YXRlIGNvbGxpZGVyID0gbnVsbDtcblxuICAgIHByaXZhdGUgZW5lbXlNYW5hZ2VyID0gbnVsbDtcblxuICAgIHByaXZhdGUgZW5lbXlTcGVlZCA9IDA7XG5cbiAgICBwdWJsaWMgaW5pdChub2RlOiBjYy5Ob2RlKVxuICAgIHsgICBcbiAgICAgICAgdGhpcy5zY29yZSA9IGNjLmZpbmQoXCJDYW52YXMvc2NvcmVcIikuZ2V0Q29tcG9uZW50KHNjb3JlKTtcblxuICAgICAgICB0aGlzLmFuaW0gPSB0aGlzLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuXG4gICAgICAgIHRoaXMuY29sbGlkZXIgPSB0aGlzLmdldENvbXBvbmVudChjYy5QaHlzaWNzQm94Q29sbGlkZXIpO1xuXG4gICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMjU1O1xuXG4gICAgICAgIHRoaXMuc2V0SW5pdFBvcyhub2RlKTtcblxuICAgICAgICB0aGlzLmFuaW0ucGxheSgnZW5lbXknKTtcbiAgICB9XG5cbiAgICAvLyB0aGlzIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aGVuIHRoZSBlbmVteSBtYW5hZ2VyIGNhbGxzIFwiZ2V0XCIgQVBJLlxuICAgIHJldXNlKGVuZW15TWFuYWdlcilcbiAgICB7XG4gICAgICAgIHRoaXMuZW5lbXlNYW5hZ2VyID0gZW5lbXlNYW5hZ2VyO1xuICAgIH1cblxuICAgIC8vdGhpcyBmdW5jdGlvbiBzZXRzIHRoZSBlbmVteSdzIGluaXRpYWwgcG9zaXRpb24gd2hlbiBpdCBpcyByZXVzZWQuXG4gICAgcHJpdmF0ZSBzZXRJbml0UG9zKG5vZGU6IGNjLk5vZGUpXG4gICAge1xuICAgICAgICB0aGlzLm5vZGUucGFyZW50ID0gbm9kZTtcblxuICAgICAgICAvLyBJIHVzZSByYW5kb20gdG8gZGVjaWRlIHdoZXJlIHRoZSBlbmVteSBhcHBlYXIgYWZ0ZXIgcmV1c2UuXG4gICAgICAgIGlmKE1hdGgucmFuZG9tKCkgPiAwLjUpXG4gICAgICAgIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5wb3NpdGlvbiA9IGNjLnYyKDYwMCwgLTExMCk7XG5cbiAgICAgICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAxO1xuXG4gICAgICAgICAgICB0aGlzLmVuZW15U3BlZWQgPSAtMjAwO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLm9mZnNldCA9IGNjLnYyKDIwLCAwKTtcblxuICAgICAgICAgICAgdGhpcy5jb2xsaWRlci5hcHBseSgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2VcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnBvc2l0aW9uID0gY2MudjIoLTYwMCwgLTExMCk7XG5cbiAgICAgICAgICAgIHRoaXMubm9kZS5zY2FsZVggPSAtMTtcblxuICAgICAgICAgICAgdGhpcy5lbmVteVNwZWVkID0gMjAwO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLmVuYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLmNvbGxpZGVyLm9mZnNldCA9IGNjLnYyKC0yMCwgMCk7XG5cbiAgICAgICAgICAgIHRoaXMuY29sbGlkZXIuYXBwbHkoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIGNoZWNrIGlmIGN1cnJlbnQgcG9zaXRpb24gaXMgb3V0IG9mIHZpZXcuXG4gICAgcHJpdmF0ZSBib3VuZGluZ0RldGVjdCgpXG4gICAge1xuICAgICAgICBpZih0aGlzLm5vZGUueCA+IDY1MCB8fCB0aGlzLm5vZGUueCA8IC02NTApXG4gICAgICAgICAgICB0aGlzLmVuZW15TWFuYWdlci5wdXQodGhpcy5ub2RlKTtcbiAgICB9XG5cbiAgICAvL2lmIHRoaXMgaXMgY2FsbGVkLCB0aGUgZW5lbXkgd2lsbCBmYWRlIG91dCBpbiAxcyBhbmQgZ28gYmFjayB0byB0aGUgZW5lbXkgcG9vbC5cbiAgICBwcml2YXRlIGRlYWRFZmZlY3QoKVxuICAgIHtcbiAgICAgICAgdGhpcy5lbmVteVNwZWVkID0gMDtcblxuICAgICAgICB0aGlzLmNvbGxpZGVyLmVuYWJsZWQgPSBmYWxzZTtcblxuICAgICAgICBsZXQgZmFkZSA9IGNjLmZhZGVPdXQoMSk7XG5cbiAgICAgICAgbGV0IGZpbmlzaGVkID0gY2MuY2FsbEZ1bmMoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5lbmVteU1hbmFnZXIucHV0KHRoaXMubm9kZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoZmFkZSwgZmluaXNoZWQpKTtcbiAgICB9XG5cbiAgICB1cGRhdGUoZHQpXG4gICAge1xuICAgICAgICB0aGlzLm5vZGUueCArPSB0aGlzLmVuZW15U3BlZWQgKiBkdDtcblxuICAgICAgICB0aGlzLmJvdW5kaW5nRGV0ZWN0KCk7XG4gICAgfVxuXG4gICAgLy9jaGVjayBpZiB0aGUgY29sbGlzaW9uIGlzIHZhbGlkIG9yIG5vdCwgYW5kIGNhbGwgXCJkZWFkRWZmZWN0XCIgaWYgdGhlIGNvbGxpc2lvbiBpcyB2YWxpZC5cbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmQ29sbGlkZXIsIG90aGVyQ29sbGlkZXIpXG4gICAge1xuICAgICAgICBpZihvdGhlckNvbGxpZGVyLm5vZGUubmFtZSA9PSBcImJ1bGxldFwiICYmICFvdGhlckNvbGxpZGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdCdWxsZXQnKS5pc1RyaWdnZXJlZClcbiAgICAgICAge1xuICAgICAgICAgICAgb3RoZXJDb2xsaWRlci5ub2RlLmdldENvbXBvbmVudCgnQnVsbGV0JykuaXNUcmlnZ2VyZWQgPSB0cnVlO1xuXG4gICAgICAgICAgICB0aGlzLnNjb3JlLmFkZE9uZVBvaW50KCk7XG5cbiAgICAgICAgICAgIHRoaXMuYW5pbS5zdG9wKCk7XG5cbiAgICAgICAgICAgIHRoaXMuZGVhZEVmZmVjdCgpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------
