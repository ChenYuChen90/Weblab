
require('./assets/Script/Bullet');
require('./assets/Script/Player');
require('./assets/Script/enemy');
require('./assets/Script/enemyManager');
require('./assets/Script/score');
require('./assets/migration/use_reversed_rotateTo');
