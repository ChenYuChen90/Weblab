"use strict";
cc._RF.push(module, '5353eyD4YdHSLFpesp5kvKK', 'NavWanderAgent');
// scripts/ai/NavWanderAgent.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var IInputControls_1 = require("../input/IInputControls");
var Agent_1 = require("./Agent");
var WaypointGraph_1 = require("./navigation/WaypointGraph");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
// TODO (3.3): Complete NavWanderAgent's behaviour using NavWanderer.
// [SPECIFICATIONS]
// - Check out the other agents to figure out what's missing, and connect
//   everything together!
//*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
var NavWanderAgent = /** @class */ (function (_super) {
    __extends(NavWanderAgent, _super);
    function NavWanderAgent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.attack = IInputControls_1.ButtonState.Rest;
        _this.interact = IInputControls_1.ButtonState.Rest;
        _this.waypointGraph = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(NavWanderAgent.prototype, "horizontalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return 0;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderAgent.prototype, "verticalAxis", {
        get: function () {
            //#region [YOUR IMPLEMENTATION HERE]
            return 0;
            //#endregion
        },
        enumerable: false,
        configurable: true
    });
    //#region [YOUR IMPLEMENTATION HERE]
    //#endregion
    NavWanderAgent.prototype.agentUpdate = function (dt) {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    // LIFE-CYCLE CALLBACKS:
    NavWanderAgent.prototype.onLoad = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    NavWanderAgent.prototype.start = function () {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    __decorate([
        property(WaypointGraph_1.default)
    ], NavWanderAgent.prototype, "waypointGraph", void 0);
    NavWanderAgent = __decorate([
        ccclass
    ], NavWanderAgent);
    return NavWanderAgent;
}(Agent_1.default));
exports.default = NavWanderAgent;

cc._RF.pop();