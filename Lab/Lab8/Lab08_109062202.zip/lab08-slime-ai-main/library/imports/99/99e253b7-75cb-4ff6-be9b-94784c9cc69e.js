"use strict";
cc._RF.push(module, '99e25O3dctP9r6blHhMnMae', 'ZSorter');
// scripts/utilities/ZSorter.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * A component that makes a node render in a way such that it appears behind nodes
 * that are located below it.
 */
var ZSorter = /** @class */ (function (_super) {
    __extends(ZSorter, _super);
    function ZSorter() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ZSorter.prototype.update = function (dt) {
        this.node.zIndex = 10000 + -this.node.y;
    };
    ZSorter = __decorate([
        ccclass
    ], ZSorter);
    return ZSorter;
}(cc.Component));
exports.default = ZSorter;

cc._RF.pop();