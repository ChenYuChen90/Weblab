"use strict";
cc._RF.push(module, '4bd90WqNlVPXYN8fxhe7dk4', 'NavWanderer');
// scripts/ai/strategies/NavWanderer.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.NavWanderer = void 0;
var Navigator_1 = require("./Navigator");
/**
 * An AI strategy that describes a random-walk behaviour on a waypoint graph.
 */
var NavWanderer = /** @class */ (function (_super) {
    __extends(NavWanderer, _super);
    function NavWanderer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** The agent's output to IInput. */
        _this._moveAxis2D = cc.Vec2.ZERO;
        // constructor(_agent: Agent, _waypointGraph: WaypointGraph) {
        //     super(_agent, _waypointGraph);
        // }
        _this._nextWaypoint = null;
        return _this;
    }
    Object.defineProperty(NavWanderer.prototype, "nextWaypoint", {
        get: function () {
            return this._nextWaypoint;
        },
        enumerable: false,
        configurable: true
    });
    NavWanderer.prototype.onTransitionFinish = function () {
        this._nextWaypoint = this.currentWaypoint.adjacentWaypoints[Math.floor(Math.random() * this.currentWaypoint.adjacentWaypoints.length)];
    };
    Object.defineProperty(NavWanderer.prototype, "horizontalAxis", {
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderer.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderer.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavWanderer.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    NavWanderer.prototype.start = function () {
        this._nextWaypoint = this.closestWaypoint;
    };
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    // TODO (3.2): Implement NavWanderer.update().
    // [SPECIFICATIONS]
    // - Trace Navigator.ts to figure out what you can use to make NavWanderer
    //   move towards the next waypoint AND call onTransitionFinish() after
    //   arriving.
    // - Hint: Two lines of code!
    //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
    NavWanderer.prototype.update = function (dt) {
        //#region [YOUR IMPLEMENTATION HERE]
        //#endregion
    };
    return NavWanderer;
}(Navigator_1.Navigator));
exports.NavWanderer = NavWanderer;

cc._RF.pop();