/** The Firebase namespace used to access Firebase functionalities. Please refer to the Firebase SDK API for actual usage.*/
declare const firebase: any;